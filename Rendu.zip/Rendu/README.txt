

----LIBRAIRIE NECESSAIRES-----

-numpy
-random
-time

• Ces librairies sont nécessaires afin de:
	-Manipuler facilement la grille (numpy)
	-Permettre de jouer contre un joueur tirant des coups aléatoirement (random)
	-Pouvoir connaitre le temps de réponse du joueur (time)

--------INSTALLATION-----------

Outre les librairies, ce programme ne requiert aucune installation spéciale.

Au lancement, il vous sera proposé de choisir entre le mode classique ( jouer contre l'IA )
et le mode "combat d'IA" ( voir l'IA s'affronter contre elle même ).

Vous pourrez alors par la suite choisir votre symbole puis qui commence le jeu. 

C'est tout !
